This is a new section to add your own modules, you can use function calls like:

Read the readme/User_Manual.pdf on how to create your own SET modules.

